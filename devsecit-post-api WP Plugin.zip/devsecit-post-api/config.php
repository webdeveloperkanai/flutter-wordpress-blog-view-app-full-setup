<?php 
    /*
        Plugin name: DEV SEC IT Post API
        Author: Kanai Shil (DEV SEC IT Pvt. Ltd.)
        Author uri: https://devsecit.com/author/webdeveloperkanai
        Description: Just Activate to get response in your news app. <a href=""> Get news app source code </a> -  &copy; <strong>DEV SEC IT </strong> - <a href=""> contact us </a> - <a href=""> setup help </a> 
        Version: 1.4.3
        Plugin uri: https://devsecit.com/plugin/devsecit-blog-api
        License: GPLv2 or later
        Text Domain: devsecit
    */

    if(isset($_GET['genme'])) { 
        require_once('wp-config.php'); 
        $con = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
            $table = $table_prefix."posts"; 
            $ps= $con->query("SELECT * FROM `$table` WHERE `post_status`='publish' and `comment_status`='open' and `post_type`='post' ORDER BY ID desc  ");  
            while($posts = $ps->fetch_array() ) {
                $id = $posts['ID'];
                $p = $con->query("SELECT * FROM `$table` WHERE `post_parent`='$id' and `post_type`='attachment' order by ID desc limit 1 "); 
                $rs = $p->fetch_array(); 
                $posts['thumbnail'] = str_replace('localhost', '192.168.43.219',$rs['guid']); 
                $posts['date'] = date('d-M-Y',strtotime($posts['post_date'])); 
                $posts['post_title'] = substr($posts['post_title'],0,60); 
                $arr[]= $posts;   
            }
            echo json_encode($arr);  
        die();
    }

?>
