## A sweetable gift for DEV SEC IT Pvt. Ltd. from Kanai Shil 

This plugin will help you to send data to your android/iOS application. Get source code on https://devsecit.com/plugins/ or https://github.com/webdeveloperkanai 

## DEV SEC IT Pvt. Ltd. 